document.getElementById('product-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Get product details from form fields
    const productName = document.getElementById('product-name').value;
    const productDescription = document.getElementById('product-description').value;
    const productPrice = document.getElementById('product-price').value;
    const productImage = document.getElementById('product-image').files[0];

    // Check if all fields are filled out
    if (!productName || !productDescription || !productPrice || !productImage) {
        alert('Please fill in all the fields!');
        return;
    }

    // Create a FormData object to send the product details
    const formData = new FormData();
    formData.append('product-name', productName);
    formData.append('product-description', productDescription);
    formData.append('product-price', productPrice);
    formData.append('product-image', productImage);

    // Send data to the server using Fetch API (replace with your actual server URL)
    fetch('upload_product_endpoint', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Product uploaded successfully!');
            // Reset the form
            document.getElementById('product-form').reset();
        } else {
            alert('Failed to upload product. Please try again.');
        }
    })
    .catch(error => {
        console.error('Error uploading product:', error);
        alert('An error occurred. Please try again later.');
    });
});
